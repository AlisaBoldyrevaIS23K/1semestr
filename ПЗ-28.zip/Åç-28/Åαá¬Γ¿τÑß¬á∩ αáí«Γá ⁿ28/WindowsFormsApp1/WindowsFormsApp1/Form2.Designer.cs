﻿namespace WindowsFormsApp1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cB2 = new System.Windows.Forms.RadioButton();
            this.cBl = new System.Windows.Forms.RadioButton();
            this.rBl = new System.Windows.Forms.CheckBox();
            this.rB2 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cB2);
            this.groupBox1.Controls.Add(this.cBl);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.groupBox1.Location = new System.Drawing.Point(105, 71);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(296, 143);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Режим работы";
            // 
            // cB2
            // 
            this.cB2.AutoSize = true;
            this.cB2.Location = new System.Drawing.Point(39, 66);
            this.cB2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cB2.Name = "cB2";
            this.cB2.Size = new System.Drawing.Size(236, 33);
            this.cB2.TabIndex = 1;
            this.cB2.TabStop = true;
            this.cB2.Text = "Меньше предела";
            this.cB2.UseVisualStyleBackColor = true;
            // 
            // cBl
            // 
            this.cBl.AutoSize = true;
            this.cBl.Location = new System.Drawing.Point(39, 38);
            this.cBl.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cBl.Name = "cBl";
            this.cBl.Size = new System.Drawing.Size(231, 33);
            this.cBl.TabIndex = 0;
            this.cBl.TabStop = true;
            this.cBl.Text = "Больше предела";
            this.cBl.UseVisualStyleBackColor = true;
            this.cBl.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // rBl
            // 
            this.rBl.AutoSize = true;
            this.rBl.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.rBl.Location = new System.Drawing.Point(572, 71);
            this.rBl.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rBl.Name = "rBl";
            this.rBl.Size = new System.Drawing.Size(116, 33);
            this.rBl.TabIndex = 1;
            this.rBl.Text = "Сумма";
            this.rBl.UseVisualStyleBackColor = true;
            this.rBl.CheckedChanged += new System.EventHandler(this.rBl_CheckedChanged);
            // 
            // rB2
            // 
            this.rB2.AutoSize = true;
            this.rB2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.rB2.Location = new System.Drawing.Point(572, 125);
            this.rB2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rB2.Name = "rB2";
            this.rB2.Size = new System.Drawing.Size(206, 33);
            this.rB2.TabIndex = 2;
            this.rB2.Text = "Произведение";
            this.rB2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label1.Location = new System.Drawing.Point(141, 416);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 29);
            this.label1.TabIndex = 3;
            this.label1.Text = "Предел";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(251, 423);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(126, 22);
            this.textBox1.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(588, 416);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(212, 64);
            this.button1.TabIndex = 5;
            this.button1.Text = "Спрятать";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rB2);
            this.Controls.Add(this.rBl);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form2";
            this.Text = "Form2";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.RadioButton cB2;
        public System.Windows.Forms.RadioButton cBl;
        public System.Windows.Forms.CheckBox rBl;
        public System.Windows.Forms.CheckBox rB2;
        public System.Windows.Forms.TextBox textBox1;
    }
}