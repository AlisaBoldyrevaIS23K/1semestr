﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace задание3
{
    internal class з3
    {
        static void Main(string[] args)
        {
            Console.Write("Введите число: ");

            if (double.TryParse(Console.ReadLine(), out double number))
            {
                if (number > 5 && number < 10)
                {
                    Console.WriteLine("Число больше 5 и меньше 10");
                }
                else
                {
                    Console.WriteLine("Неизвестное число");
                }
            }
            else
            {
                Console.WriteLine("Введено некорректное значение. Пожалуйста, введите число.");
            }
        }
    }
}