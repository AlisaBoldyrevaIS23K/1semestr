﻿using System;

namespace задание4
{
    internal class з4
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите сумму вклада:");
            double depositAmount = Convert.ToDouble(Console.ReadLine());

            double interestRate;

            if (depositAmount < 100)
            {
                interestRate = 0.05;
            }
            else if (depositAmount >= 100 && depositAmount <= 200)
            {
                interestRate = 0.07;
            }
            else
            {
                interestRate = 0.10;
            }

            double interest = depositAmount * interestRate;
            double finalAmount = depositAmount + interest;

            Console.WriteLine($"Сумма вклада с начисленными процентами: {finalAmount:C}");
        }
    }
}