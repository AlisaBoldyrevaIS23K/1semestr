﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace задание2
{
    internal class з2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("введите число: ");
            if (double.TryParse(Console.ReadLine(), out double number))
            {
                // Проверка условия
                if (number > 5 && number < 10)
                {
                    Console.WriteLine("Число больше 5 и меньше 10");
                }
                else
                {
                    Console.WriteLine("Неизвестное число");
                }
            }
            else
            {
                Console.WriteLine("Введено некорректное значение. Пожалуйста, введите число.");
            }
        }
    }
}